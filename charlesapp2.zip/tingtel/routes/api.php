<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});



Route::post('/register','ApiController@register');
Route::post('/login','ApiController@login');
Route::post('/sms_receipt','ApiController@sms_receipt');
Route::post('/ussd_receipt','ApiController@ussd_receipt');

Route::post('/ussd_receipt2','ApiController@ussd_receipt2');
Route::post('/OTP','ApiController@OTP');
//Route::post('/Report_Issue','ApiController@Issue_Reports');
Route::post('/manage_sim','ApiController@manage_sim');
Route::post('/Report_Issue','ApiController@Issue_Reports');
Route::post('/setpassword','ApiController@setpassword');
Route::post('/changeemail','ApiController@changeemail');
Route::post('/changepassword','ApiController@changepassword');

Route::post('/forgot_password','ApiController@forgot_password');
Route::post('/user_info','ApiController@user_info');
Route::post('/received_info','ApiController@received_info');
Route::post('/transfer_credit','ApiController@transfer_credit');
Route::post('/credit_notification_push','ApiController@credit_notification_push');
Route::post('/credit_update_report','ApiController@credit_update_report');
Route::post('/OTP','ApiController@OTP');

Route::post('get_transaction_history','ApiController@get_transaction_history');
Route::post('deleteAccount','ApiController@deleteAccount');
Route::post('delete_single_transaction','ApiController@delete_single_transaction');

Route::post('delete_sim','ApiController@delete_sim');


Route::post('/addsim','ApiController@addsim');
Route::post('/validate_user','ApiController@validate_user');

Route::post('sms_receipt2','ApiController@sms_receipt2');
Route::post('sms_receipt3','ApiController@sms_receipt3');

Route::post('test_curl','ApiController@test_curl');


