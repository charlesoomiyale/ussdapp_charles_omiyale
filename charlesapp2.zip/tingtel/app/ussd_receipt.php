<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ussd_receipt extends Model
{
    //billing
   protected $table='ussd_receipt';
}
