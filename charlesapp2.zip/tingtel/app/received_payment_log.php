<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class received_payment_log extends Model
{
    //billing
   protected $table='received_payment_log';
}
