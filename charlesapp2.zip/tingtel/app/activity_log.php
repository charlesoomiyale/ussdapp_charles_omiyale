<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class activity_log extends Model
{
    //billing
   protected $table='activity_log';
}
