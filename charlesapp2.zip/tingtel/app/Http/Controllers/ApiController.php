<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\ArrayToXml\ArrayToXml;
use stdClass;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Validator;
use App\User;
use App\Transaction;
use App\Issue_Reports;
use App\sms_receipt;
use App\ussd_receipt;
use App\activity_log;
use App\received_payment_log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
class ApiController extends Controller
{
    public function register(Request $request)
    {
        $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;
$password = $request->header('Password');
$username = $request->header('Username');

if($username=="tingtel" && $password=="967@1#-%3*")
{
     try{
$email=$request->email;
//$phone=$request->phone;
$hash=$request->hash;
$hash_key="CBOPAY967834612944";
$data=$email.$request->sim1['phone'].$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
  return response()->json(['code'=>'9999','description'=>'Invalid Hash Key']);
}
$match=['phone'=>$request->sim1['phone']];   //,'email'=>$request->email
$result=User::where($match)->first();
if(isset($result))
{
     return response()->json(['code'=>'9999','description'=>'user already exist']);
    
}


$match=['email'=>$request->email];   //,'email'=>$request->email
$result=User::where($match)->first();
if(isset($result))
{
return response()->json(['code'=>'9999','description'=>'Email already exist']);
}

$match=['username'=>$request->username];   //,'email'=>$request->email
$result=User::where($match)->first();
if(isset($result))
{
return response()->json(['code'=>'9999','description'=>'Username already exist']);
}

        $usr=new User();
        $usr->phone=$request->sim1['phone'];
        $usr->first_name=$request->first_name;
        $usr->last_name=$request->last_name;
        $usr->email=$request->email;
        $usr->user_network=$request->sim1['user_network'];
        $usr->username=$request->username;
        $usr->password=bcrypt($request->password);
        $usr->ip=$ip;
        $usr->log=$longitude;
        $usr->lat=$latitude;
        $usr->serial_number=$request->sim1['serial_number'];
        $usr->sim1_serial=$request->sim1['serial_number'];
        $usr->latitude_dec=$latitude_dec;
        $usr->nationality=$nationality;
        $usr->save();
        
        if(isset($request->sim2['phone']))
        {
     DB::table('users')
    ->where('id',$usr->id)
    ->update(['phone2' =>$request->sim2['phone'],'sim2_serial'=>$request->sim2['serial_number'],'sim2_user_network'=>$request->sim2['user_network']]);
        }
        
        return response()->json(['code'=>'0000','description'=>'successfully registered user']);

    }catch(\Exception $ex)
    {
    return response()->json(['code'=>'9999',"description"=>'server error']);
    }
}else{
    return response()->json(['code'=>'9996',"description"=>'Invalid Header Parameter']);
}
    }
    public function changepassword(Request $request)
    {
       $this->validate($request, [
        'email' => 'required',
        'phone' => 'required',
        'hash' => 'required',
    ]);
 
    $email=$request->email;
    $phone=$request->phone;
    $hash=$request->hash;
    $hash_key="CBOPAY967834612944";
    $data=$email.$phone.$hash_key;
    $hashed =hash('sha512', $data);
    if($hash!=$hashed)
    {
    return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
    }
  try{
      
    $match=['phone'=>$request->phone,'email'=>$request->email];   
    $result=User::where($match)->first();
    if(!isset($result))
    {
        return response()->json(['code'=>'9999',"description"=>'user not registered']);
    }
    DB::table('users')
    ->where('id',$result->id)
    ->update(['password' =>bcrypt($request->password)]);
     return response()->json(['code'=>'0000',"description"=>'password updated successfully']);
  }
  catch(\Exception $ex)
  {
      
 return response()->json(['code'=>'9997',"description"=>'server error']);
   }

  }
  
  
  public function forgot_password(Request $request)
  {
    $phone=$request->phone;
    $hash=$request->hash;
    $hash_key="CBOPAY967834612944";
    $data=$phone.$hash_key;
    $hashed =hash('sha512', $data);
    if($hash!=$hashed)
    {
    return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
    }
    
    $match=['phone'=>$request->phone];   
    $result=User::where($match)->first();
    if(!isset($result))
    {
        return response()->json(['code'=>'9999',"description"=>'user not registered']);
    }
    DB::table('users')
    ->where('id',$result->id)
    ->update(['password' =>bcrypt($request->password)]);
     return response()->json(['code'=>'0000',"description"=>"New password Set successfully"]);
    
      
  }

 public function setpassword(Request $request)
 {
   $this->validate($request, [
        'email' => 'required',
        'phone' => 'required',
        'hash' => 'required',
    ]);


$email=$request->email;
$phone=$request->phone;
$hash=$request->hash;
$hash_key="CBOPAY967834612944";
$data=$phone.$email.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
}



    try{
        $match=['phone'=>$request->phone,'email'=>$request->email];   
        $result=User::where($match)->first();
        
        if(!isset($result))
        {
            return response()->json(['code'=>'9999',"description"=>'user not registered']);
        }
        DB::table('users')
        ->where('id',$result->id)
        ->update(['password' =>bcrypt($request->password)]);
        return response()->json(['code'=>'0000','description'=>'Password Set successfully']);
      }catch(\Exception $ex)
      {
     return response()->json(['code'=>'9997',"description"=>'server error']);
       }
    

 }
 public function changeemail(Request $request)
 {

    $this->validate($request, [
        'email' => 'required',
        'phone' => 'required',
        'hash' => 'required',
    ]);

$email=$request->email;
$phone=$request->phone;
$hash=$request->hash;
$hash_key="CBOPAY967834612944";
$data=$email.$phone.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
}
try{

        $match=['phone'=>$request->phone];   
        $result=User::where($match)->first();
        
        if(!isset($result))
        {
            return response()->json(['code'=>'9999',"description"=>'user not registered']);
        }
        DB::table('users')
        ->where('id',$result->id)
        ->update(['email' =>$request->email]);

        return response()->json(['code'=>'0000','description'=>'Email Changed successfully']);
      }catch(\Exception $ex)
      {
    
     return response()->json(['code'=>'9997',"description"=>'server error']);
       }
 }
 public function deleteAccount(Request $request)
 {
   

   $password = $request->header('Password');
    $username = $request->header('Username');
  //$email=$request->email;
  $phone=$request->user_phone;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$username.$password.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }
    try{
        
        $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
        $user_match=['phone'=>$phone];
        $user=User::where($user_match)->first();
        
         if(!isset($user))
        {
             return response()->json(['code'=>'9998','description'=>'No such User']);
            
        }
        //save the activity log
        $active=new activity_log();
        $active->user_id=$user->id;
        $active->ip=$ip;
        $active->log=$longitude;
        $active->lat=$latitude;
        $active->nationality=$nationality;
        $active->log_dec=$latitude_dec;
        $active->action='Delete Account';
        $active->save(); 
        
        $match=['phone'=>$request->user_phone,'email'=>$request->email];   
        $result=User::where($match)->first();
        if(!isset($result))
        {
             return response()->json(['code'=>'9999','description'=>'Account does not exist']);
            
        }
        $match=['id'=> $result->id];
        DB::table('users')->where($match)->delete();
        return response()->json(['code'=>'0000','description'=>'Account Deleted Successfully']);
    }
    catch(\Exception $ex)
    {
        return response()->json(['code'=>'9997','description'=>'Server Error']);
    }
   
 }
 
 public function delete_single_transaction(Request $request)
 {
      $password = $request->header('Password');
    $username = $request->header('Username');
  //$email=$request->email;
  $phone=$request->user_phone;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$username.$password.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }
   try{
        
        $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
        $user_match=['phone'=>$phone];
        $user=User::where($user_match)->first();
        
         if(!isset($user))
        {
             return response()->json(['code'=>'9997','description'=>'No such User']);
            
        }
        
        //save the activity log
        $active=new activity_log();
        $active->user_id=$user->id;
        $active->ip=$ip;
        $active->log=$longitude;
        $active->lat=$latitude;
        $active->nationality=$nationality;
        $active->log_dec=$latitude_dec;
        $active->action='Delete Single Transactions';
        $active->save(); 
        
        $match=['ref'=>$request->ref];   
        DB::table('transaction')->where($match)->delete();
        return response()->json(['code'=>'0000','description'=>'transaction deleted']);
    }
    catch(\Exception $ex)
    {
        return response()->json(['code'=>'9997','description'=>'Server Error']);
    }
   
     
 }
 
 public function delete_sim(request $request)
 {
  $password = $request->header('Password');
  $username = $request->header('Username');
  //$email=$request->email;
  $phone=$request->phone;
  $sim_number=$request->phone_number;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$username.$password.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }
    try{
        
        $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
         
        $user_match=['phone'=>$phone];
        $user=User::where($user_match)->first();
        
     
        //save the activity log
        if(!isset($user))
        {
             return response()->json(['code'=>'9998','description'=>'No such User']);
            
        }
        $active=new activity_log();
        $active->user_id=$user->id;
        $active->ip=$ip;
        $active->log=$longitude;
        $active->lat=$latitude;
        $active->nationality=$nationality;
        $active->log_dec=$latitude_dec;
        $active->action='Delete Sim';
        $active->save(); 
        
        if($sim_number==$user->phone2)
        {
            DB::table('users')
->where('phone',$phone)
->update(['phone2' =>null,'sim2_serial'=>null,'sim2_user_network'=>null]);
        }
        
         if($sim_number==$user->phone3)
        {
            DB::table('users')
->where('phone',$phone)
->update(['phone3' =>null,'sim3_serial'=>null,'sim3_user_network'=>null]);
        }
         if($sim_number==$user->phone4)
        {
            DB::table('users')
->where('phone',$phone)
->update(['phone4' =>null,'sim4_serial'=>null,'sim4_user_network'=>null]);
        }
        
    return response()->json(['code'=>'0000','description'=>'sim deleted']);
    }
    catch(\Exception $ex)
    {
        return response()->json(['code'=>'9997','description'=>'Server Error']);
    }
     
     
 }
   public function get_transaction_history(Request $request)
   {
  $password = $request->header('Password');
  $username = $request->header('Username');
  $phone=$request->user_phone;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$username.$password.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }
  
  $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
    $user_match=['phone'=>$phone];
    $user=User::where($user_match)->first();
    
    if(!isset($user))
    {
    return response()->json(['code'=>'9999','description'=>'User Does Not Exist']); 
    }
    //save the activity log
    $active=new activity_log();
    $active->user_id=$user->id;
    $active->ip=$ip;
    $active->log=$longitude;
    $active->lat=$latitude;
    $active->nationality=$nationality;
    $active->log_dec=$latitude_dec;
    $active->action='transaction_history';
    $active->save(); 
 
     $match=['user_phone'=>$phone];
     $user_match=['phone'=>$phone];
      $tranc3=[];
      $tranc4=[];
      $tranc2=[];
      
      $results=[];
      
     $user=User::where($user_match)->first();
     if(isset($user))
     {
         if(isset($user->phone2))
         {
        $match2=['user_phone'=>$user->phone2];
         $tranc2= Transaction::where($match2)
        ->get();
         }
         if($user->phone3)
         {
        $match2=['user_phone'=>$user->phone3];
        $tranc3= Transaction::where($match2)
        ->get();
         }
         if($user->phone4)
         {
         $match2=['user_phone'=>$user->phone4];
         $tranc4= Transaction::where($match2)->get();
         }
         
         
         
     }else
     {
         $tranc2=[];
     }
     
     $tranc= Transaction::where($match)
     ->get();
     
     //return $tranc;
     
     if(count($tranc)==0 && count($tranc2)==0)
     {
         
         return response()->json(['code'=>'9999','description'=>'no transaction record',"transactions"=>$tranc]); 
         
     }
     if(count($tranc2)==0)
     {
         $tranc2=[];
     }
    
    

$obj=new stdClass;
$obj->phone_number=$user->phone;
$obj->transaction_history=$tranc;

array_push($results,$obj);
$obj2=new stdClass;
$obj2->phone_number=$user->phone2;
$obj2->transaction_history=$tranc2;
array_push($results,$obj2);

$obj3=new stdClass;
$obj3->phone_number=$user->phone4;
$obj3->transaction_history=$tranc3;

array_push($results,$obj3);

$obj4=new stdClass;
$obj4->phone_number=$user->phone4;
$obj4->transaction_history=$tranc4;

array_push($results,$obj4);

 return response()->json(['code'=>'0000',"results"=>$results]);
   
   }
   
   public function user_info(Request $request)
   {
      
        $this->validate($request, [
        'email' => 'required',
        'phone' => 'required',
        'hash' => 'required',
        
    ]);
    $password = $request->header('Password');
    $username = $request->header('Username');
    if($username=="tingtel" && $password=="967@1#-%3*")
    {
    try{
        
  $email=$request->email;
  $phone=$request->phone;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$email.$phone.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }

$ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
    $user_match=['phone'=>$phone];
    $user=User::where($user_match)->first();
    //save the activity log
    $active=new activity_log();
    $active->user_id=$user->id;
    $active->ip=$ip;
    $active->log=$longitude;
    $active->lat=$latitude;
    $active->nationality=$nationality;
    $active->log_dec=$latitude_dec;
    $active->action='user_info';
    $active->save(); 
          
     $match=['phone'=>$request->phone,'email'=>$request->email];   
     $users = DB::table('users')
                ->where($match)
                ->select('first_name','last_name','user_network','username','ip','log','lat','email','phone','phone2')
                ->get(); 
   return response()->json($users);
    }catch(\Exception $ex)
    {
    return response()->json(['code'=>'9999',"description"=>'server error']);
        
    }
    }else
    {
       return response()->json(['code'=>'9996',"description"=>'Invalid Header Parameter']);
    }
   }
   
   public function received_info(Request $request)
   {
    $password = $request->header('Password');
    $username = $request->header('Username');
    if($username=="tingtel" && $password=="967@1#-%3*")
    {

  try{
  $phone=$request->phone;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$username.$password.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }

$ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
   
    //save the activity log
    // $active=new activity_log();
    // $active->user_id=$user->id;
    // $active->ip=$ip;
    // $active->log=$longitude;
    // $active->lat=$latitude;
    // $active->nationality=$nationality;
    // $active->log_dec=$latitude_dec;
    // $active->action='received_info';
    // $active->save(); 
          
     $match=['phone'=>$request->phone];   
     $received = DB::table('received_payment_log')
                ->where($match)
                ->select('name','sender','phone','trans_id','sent','amount','created_at')
                ->get(); 
   return response()->json(['code'=>'0000',"description"=>'successful','data'=>$received]);
    }catch(\Exception $ex)
    {
    return response()->json(['code'=>'9999',"description"=>'server error']);
        
    }
    }else
    {
       return response()->json(['code'=>'9996',"description"=>'Invalid Header Parameter']);
    }
       
       
   }
   public function manage_sim(Request $request)
   {

      $this->validate($request, [
        'email' => 'required',
        'phone' => 'required',
        'hash' => 'required',
    ]);
  
  $password = $request->header('Password');
$username = $request->header('Username');
 if($username=="tingtel" && $password=="967@1#-%3*")
 {
     $email=$request->email;
  $phone=$request->phone;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$phone.$email.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }

  
//To allow users to deactivate or delete a number registered.
try
{
  $match=['phone'=>$request->phone,'email'=>$request->email];   
  $result=User::where($match)->first();
  
if(!isset($result))
{
  return response()->json(['code'=>'9999',"description"=>'user not registered']);
}
if($request->active=='0')
{
$active=0;
}
else if($request->active=='1')
{
  $active=1;
}
else 
{

return response()->json(['code'=>'9999','description'=>'Invalid active perameter']);
}

DB::table('users')
->where('id',$result->id)
->update(['is_active' =>$active]);
return response()->json(['code'=>'0000','description'=>'Email Changed successfully']);

}catch(\Exception $ex)
{

return response()->json(['code'=>'9997','description'=>'Server Error']);
  
}

 }else
 {
     
     
     
 }
 

}
public function Issue_Reports(Request $request)
{
    $this->validate($request, [
        'email' => 'required',
        'phone' => 'required',
        'hash' => 'required',
    ]);
$password = $request->header('Password');
$username = $request->header('Username');
 if($username=="tingtel" && $password=="967@1#-%3*")
 {
     try{
    
$email=$request->email;
$phone=$request->phone;
$hash=$request->hash;
$hash_key="CBOPAY967834612944";
$data=$email.$phone.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
}
   $issue=new Issue_Reports();
   $issue->issue=$request->message;
   $issue->msisdn=$request->phone;
   $issue->email=$request->email;
   $issue->save();
  return response()->json(['code'=>'0000','description'=>'Issue Reported successfully']);
    
}catch(\Exception $ex)
{
    return response()->json(['code'=>'9999','description'=>'Server Error'.$ex]);
}

 }else
 {
    return response()->json(['code'=>'9996',"description"=>'Invalid Header Parameter']);
 }
}

public function sms_receipt(Request $request)
{   
    

//   $final_stage=false;
//   $sim_airtel_first=false;
//   Log::info(print_r($_GET,true));
//   Log::info(print_r($_POST,true));
//   Log::info(print_r($_FILES,true));

//   $keyword=$request->keyword;
//   $server=$request->server;
//   $message=$request->message;
//   $ref=$request->ref;
//     $sim=$request->sim;
//   $date=$request->date;
//   Log::info((string)$message);
//   if($sim=="08133469004")
//   {
//   $array = explode(' ', $message);
//   $sender=$array[6];
//   $amount=$array[0];
//   $keyword=$array[2];
//   $amount = ltrim($amount, 'N');
//   $amount=(int)$amount;
  
//   }
   
//   else if($sim=="09048120037")
//   {
       
//   if (stripos($message, "Transferred") !== false) {
//     $sim_airtel_first=true;
// }
//     if($sim_airtel_first==true)
//     {
//   $array = explode(' ',$message);
//   $sender='234'.$array[7];
//   $amount=$array[4];
//   $keyword=$array[10];
 
//   $amount=(int)$amount;
        
//     }else{
//     $array = explode(' ', $message);
//     $sender='234'.$array[9];
//     $amount=$array[6];
//     $keyword=$array[5];
//     $amount=(int)$amount;
//     }
// if($keyword=="sent")
// {
//     $keyword="transferred";
// }else if($keyword=="Transferred")
//       $keyword="transferred";
//  }

//   $sender=rtrim($sender, ".");
//   $match=['user_phone'=>$sender,'amount'=>$amount,'status'=>0 ,'api_ref'=>null];
//   $transearc=Transaction::where($match)->first();
//   if(!isset($transearc))
//   {
//   $match=['beneficiary_msisdn'=>$sender,'amount'=>$amount,'status'=>0,'api_ref'=>null];
//   $transearc=Transaction::where($match)->first();
//   }
//   if(isset($transearc))
//   {
//     $network=$transearc->beneficiary_network;
//     if($transearc->api_ref!=null)
//     {
//       $final_stage=true;
//     }
//   }
//   if(!isset($transearc))
//   {
//       return "no such transaction" ;
       
//   }
//   if($keyword=="transferred")
//   {
//      if($final_stage==true){
//     DB::table('transaction')
//     ->where($match)
//     ->update(['status' =>1]);
//      exit;
//      }
// $url="https://simhostng.com/api/ussd";
// $apiKey="175f620ef9c5d93f69045f6f646dff307bfb3c207a0c366058b84df75addf676";
// $ref=$transearc->ref;
// $callback="http://45.58.119.26/tingtel/api/ussd_receipt";
// if($network=="9mobile")
// {
// $server="CLMTNBFFF";
// //try{ 
// $number="*223*"."0000*".$transearc->amount.'*'.$transearc->amount."*".$transearc->beneficiary_msisdn."#";
// $data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;
// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL,$url);
// curl_setopt($ch, CURLOPT_POST, 1);
//  curl_setopt($ch, CURLOPT_RETURNTRANSFER,true); 
// curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
// $server_output = curl_exec ($ch);
// curl_close ($ch);
// $result=json_decode($server_output);
// $data=$result->data;
// $ref=$data[0]->ID;
// $response=$data[0]->RESPONSE;

//  DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$ref,'status'=>2]);

//  //return response()->json($data);
    
// // }catch(\Exception $ex)
// // {
// //     return response()->json(['code'=>'9999',"description"=>'server error']);
    
    
// // }
// }
// else if(strtolower($network)=="airtel")
// {
   
//  //try{
//       $server="CLAIRUCPN";
//      $number="*432*1*".$transearc->beneficiary_msisdn.'*'.$transearc->amount."*"."1234"."#";
// $data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;

//  Log::info((string)$data_string);

// $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL,$url);
// curl_setopt($ch, CURLOPT_POST, 1);
//  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
// curl_setopt($ch, CURLOPT_POSTFIELDS,
//             $data_string);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
// $server_output = curl_exec ($ch);

//  Log::info((string)print_r($server_output,true));
//  $result=json_decode($server_output);
// $data=$result->data;
// $ref=$data[0]->id;
// $response=$data[0]->response;
// DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$ref,'status'=>2]);
    
   
//  curl_close ($ch);
// //return $server_output;
// //  }catch(\Exception $ex)
// //  {
// //       return response()->json(['code'=>'9999',"description"=>'server error']);
     
// //  }  
// }else if(strtolower($network)=="mtn")
// {

//   // try{
//     $number="*600*".$transearc->beneficiary_msisdn.'*'.$transearc->amount."*"."1234"."#";
// //This is the breakdown - *600*RECEIPIENT*AMOUNT*PIN#
//     $server="CLMTNRTDV";
//     $data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;
//     $ch = curl_init();
//     curl_setopt($ch, CURLOPT_URL,$url);
//     curl_setopt($ch, CURLOPT_POST, 1);
//     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
//     curl_setopt($ch, CURLOPT_POSTFIELDS,
//             $data_string);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
// $server_output = curl_exec ($ch);
// $result=json_decode($server_output);
// Log::info((string)print_r($server_output, true));

// $data=$result->data;
// $ref=$data[0]->id;
// $response=$data[0]->response;

//  DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$ref,'status'=>2]);
    
    
    
// curl_close ($ch);

     
// //  }catch(\Exception $ex)
// //  {
// // return response()->json(['code'=>'9999',"description"=>'server error']);
     
// //  }  
    
    
// }else if(strtolower($network)=="glo")
// {
//      try{
//         $id=self::gen_uuid();
//         $ch = curl_init();
//       $data = array("msisdn" =>$transearc->beneficiary_msisdn, "amount"=>$transearc->amount,"trans_id"=>$id,'hash'=>'1483f7993dc5ad1d939333780314496c067f95995fc51094b1a25739d71334fee45cb12ed8ea547e92aff81bee4ab8ce8e85616baadc98c58e4ff3d01646315c');       
//       $data_string = json_encode($data);             
//       //$ch = curl_init('https://cloud-sdp.com/api/topup');
//       $ch = curl_init('https://ucard.com.ng/api/tingtelairtime');
      
//       curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
//       curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);  
//       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
//       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
//       curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//       curl_setopt($ch, CURLOPT_HTTPHEADER, array(  
//                 'Content-Type: application/json',
//                 "Username:" .'tingtel',
//                 "Password:".'@!23tingtel#123',
//              'Content-Length: ' . strlen($data_string)));              
//               $result = curl_exec($ch);
//               curl_close($ch);
// if ($result === false) 
//  {
//      $result = curl_error($ch);
//  }
//  $array = json_decode($result, true);

 
//  if($array['code']=="0000")
//  {
     
//      DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>2]);
//     return response()->json(['code'=>'0000',"description"=>'successful']);
     
     
//  }else
//  {
     
//         DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>1]);
//     return response()->json(['code'=>'9997',"description"=>'failed']);
     
//  }
//         }
//         catch(\Exception $ex)
//         {
    
//       DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>1]);
//     return response()->json(['code'=>'9997',"description"=>'failed!']);
            
//         }
// }  

// else if(strtolower($network)=="9mobile")
// {
//       try{
//         $id=self::gen_uuid();
//         $ch = curl_init();
//       $data = array("msisdn" =>$transearc->beneficiary_msisdn, "amount"=>$transearc->amount,"trans_id"=>$id,'hash'=>'1483f7993dc5ad1d939333780314496c067f95995fc51094b1a25739d71334fee45cb12ed8ea547e92aff81bee4ab8ce8e85616baadc98c58e4ff3d01646315c');       
//       $data_string = json_encode($data);             
//       //$ch = curl_init('https://cloud-sdp.com/api/topup');
//       $ch = curl_init('https://ucard.com.ng/api/tingtelairtime');
      
//       curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
//       curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);  
//       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
//       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
//       curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//       curl_setopt($ch, CURLOPT_HTTPHEADER, array(  
//                 'Content-Type: application/json',
//                 "Username:" .'tingtel',
//                 "Password:".'@!23tingtel#123',
//              'Content-Length: ' . strlen($data_string)));              
//               $result = curl_exec($ch);
//               curl_close($ch);
// if ($result === false) 
//  {
//      $result = curl_error($ch);
//  }
//  $array = json_decode($result, true);

 
//  if($array['code']=="0000")
//  {
//      DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>2]);
//     return response()->json(['code'=>'0000',"description"=>'successful']);
//  }else
//  {
     
//         DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>1]);
//     return response()->json(['code'=>'9997',"description"=>'failed']);
     
//  }
//         }
//         catch(\Exception $ex)
//         {
    
//       DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>1]);
//     return response()->json(['code'=>'9999',"description"=>'failed!']);
            
//         }
    
    
// }
       
       
//   }

 $transfer=false;
 Log::info(print_r($_POST,true));  
   
 if(isset($_POST['message']))
   {
        $message=$_POST['message'];
   }

 if(isset($_POST['content']))
   {
        $message=$_POST['content'];
   }
  
   if(!isset($message))
   {
       
        $message=$request->message;
       
       
   }
 Log::info("Message: ".$message);
$numbers=self::extract_phones($message);


foreach($numbers as $num)
{
 
    if(strlen($num)>10)
    {
        $sender=$num;
    }


if(strlen($num)==10)
{
    $sender='234'.$num;
    
}

if(strlen($num)==11)
{
    $sender = substr($num, 1);
    $sender='234'.$sender;
    
}

if(strlen($num)==13)
{
    $sender=$num;
    
}

}

$message=strtolower($message);
if(stripos($message,"transferred")!== false || stripos($message,"received")!==false || stripos($message,"transfered")!==false) {
    $transfer=true;
}

Log::info("will post work: "."  ".(string)$sender);
$match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null];
$transearc=Transaction::where($match)->orderBy('id', 'DESC')
->first();

 if(!isset($transearc))
   {
   $match=['beneficiary_msisdn'=>$sender,'status'=>0,'api_ref'=>null];
   $transearc=Transaction::where($match)->orderBy('id', 'DESC')
   ->first();
   }
   
 if(!isset($transearc))
 {
     
       return response()->json(['code'=>'9999',"description"=>'No such transaction']);
 }

if($transfer==false)
{
return response()->json(['code'=>'9999',"description"=>'Not Transferred, failed message received']);
}

//try{
$bene=$transearc->beneficiary_msisdn;
$amount=$transearc->amount;
$id=self::gen_uuid();
$result=self::credit_number($bene,$amount,$id);
$array = json_decode($result, true);
 if($array['code']=="0000")
 {
    $match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null,'id'=>$transearc->id];
     DB::table('transaction')
    ->where($match)
    ->update(['api_ref'=>$id,'status'=>2]);
    
    //save into received transaction log
    $name=self::findname($transearc->user_phone);
    $received=new received_payment_log();
    $received->sender=$transearc->user_phone;
    $received->phone=$bene;
    $received->name=$name;
    $received->amount=$transearc->amount;
    $received->trans_id=$transearc->ref;
    $received->save();
    return response()->json(['code'=>'0000',"description"=>'successful']);
 }else
 {
     $match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null,'id'=>$transearc->id];
    DB::table('transaction')
    ->where($match)
    ->update(['api_ref'=>$id,'status'=>1]);
    return response()->json(['code'=>'9999',"description"=>'failed'.$array['code']]);
 }
//}
// catch(\Exception $ex)
// {
//     DB::table('transaction')
//     ->where($match)
//     ->update(['api_ref'=>$id,'status'=>1]);
//     return response()->json(['code'=>'9999',"description"=>'failed!'.$ex]);
            
// }
}

public function sms_receipt2(Request $request)
{   
    $transfer=false;
   Log::info(print_r($_POST,true));  
   
   if(isset($_POST['message']))
   {
        $message=$_POST['message'];
   }

   if(isset($_POST['content']))
   {
        $message=$_POST['content'];
   }
  
   if(!isset($message))
   {
       
        $message=$request->message;
       
       
   }

  
 Log::info("Message: ".$message);
$numbers=self::extract_phones($message);
foreach($numbers as $num)
{
    if(strlen($num)>10)
    {
        $sender=$num;
    }

if(strlen($num)==10)
{
    $sender='234'.$num;
    
}

if(strlen($num)==11)
{
    $sender = substr($num, 1);
    $sender='234'.$sender;
}

if(strlen($num)==13)
{
    $sender=$num;
    
}

}

$message=strtolower($message);
if(stripos($message,"transferred")!== false || stripos($message,"received")!==false || stripos($message,"transfered")!==false) {
    $transfer=true;
}

Log::info("will post work: "."  ".(string)$sender);
$match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null];
$transearc=Transaction::where($match)->orderBy('id', 'DESC')
->first();

 if(!isset($transearc))
   {
  $match=['beneficiary_msisdn'=>$sender,'status'=>0,'api_ref'=>null];
  $transearc=Transaction::where($match)->orderBy('id', 'DESC')
->first();
   }
   
 if(!isset($transearc))
 {
     
       return response()->json(['code'=>'9999',"description"=>'No such transaction']);
 }

if($transfer==false)
{
return response()->json(['code'=>'9999',"description"=>'Not Transferred, failed message received']);
}

try{
$bene=$transearc->beneficiary_msisdn;
$amount=$transearc->amount;
$id=self::gen_uuid();
$result=self::credit_number($bene,$amount,$id);

$array = json_decode($result, true);
 if($array['code']=="0000")
 {
     $match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null,'id'=>$transearc->id];
     DB::table('transaction')
    ->where($match)
    ->update(['api_ref'=>$id,'status'=>2]);
    
    //save into received transaction log
    $name=self::findname($transearc->user_phone);
    $received=new received_payment_log();
    $received->sender=$transearc->user_phone;
    $received->phone=$bene;
    $received->name=$name;
    $received->amount=$transearc->amount;
    $received->trans_id=$transearc->ref;
    $received->save();
    return response()->json(['code'=>'0000',"description"=>'successful']);
 }else
 {
    $match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null,'id'=>$transearc->id];
    DB::table('transaction')
    ->where($match)
    ->update(['api_ref'=>$id,'status'=>1]);
    return response()->json(['code'=>'9999',"description"=>'failed'.$array['code']]);
 }
}
catch(\Exception $ex)
{
    $match=['user_phone'=>$sender,'status'=>0 ,'api_ref'=>null,'id'=>$transearc->id];
      DB::table('transaction')
    ->where($match)
    ->update(['api_ref'=>$id,'status'=>1]);
    return response()->json(['code'=>'9999',"description"=>'failed!'.$ex]);
            
}
}

public function sms_receipt3(Request $request)
{
	Log::info(print_r($_POST,true));
	Log::info("Request: ".(String)$request);    
}

public function credit_number($bene,$amount,$id)
{
       // $id=self::gen_uuid();
        $ch = curl_init();
        $amount=(int)$amount;
       $data = array("msisdn" =>$bene, "amount"=>$amount,"trans_id"=>$id,'hash'=>'1483f7993dc5ad1d939333780314496c067f95995fc51094b1a25739d71334fee45cb12ed8ea547e92aff81bee4ab8ce8e85616baadc98c58e4ff3d01646315c');       
       $data_string = json_encode($data);    
       //$ch = curl_init('https://cloud-sdp.com/api/topup');
       $ch = curl_init('https://ucard.com.ng/api/tingtelairtime');
       curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
       curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);  
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
       curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
       curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
       curl_setopt($ch, CURLOPT_HTTPHEADER, array(  
                'Content-Type: application/json',
                "Username:" .'tingtel',
                "Password:".'@!23tingtel#123',
             'Content-Length:' .strlen($data_string)));              
               $result = curl_exec($ch);
               curl_close($ch);
if ($result === false) 
 {
     $result = curl_error($ch);
 }
 
 return $result;
    
}


function extract_phones($str) {
    preg_match_all('/\d+/', $str, $matches);
    return $matches[0];
}

function findname($phone)
{
$user_match=['phone'=>$phone];
$user=User::where($user_match)->first();

if(!isset($user))
{
$user_match=['phone2'=>$phone];
$user=User::where($user_match)->first();
    
}

if(!isset($user))
{
$user_match=['phone3'=>$phone];
$user=User::where($user_match)->first();
}
if(!isset($user))
{
$user_match=['phone4'=>$phone];
$user=User::where($user_match)->first();
}
return $user->username;
}
public function addsim(Request $request)
{
$password = $request->header('Password');
$username = $request->header('Username');

$phone=$request->user_phone;
$phone2=$request->new_phone;
$sim2_network=$request->sim_network;
$sim2_serial=$request->sim_serial;
$hash=$request->hash;
$hash_key="CBOPAY967834612944";
$data=$username.$password.$hash_key;
$hashed =hash('sha512', $data);

 $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }
  
    $user_match=['phone'=>$phone];
    $user=User::where($user_match)->first();
    
    //return $user;
    
    if($user->phone2==null || $user->phone2=='')
    {
     DB::table('users')
    ->where('phone',$phone)
    ->update(['phone2' =>$phone2,'sim2_serial'=>$sim2_serial,'sim2_user_network'=>$sim2_network]);
    return response()->json(['code'=>'0000',"description"=>'Sim Added']);
        
    }
    
    else if($user->phone3==null || $user->phone3=='')
    {
     DB::table('users')
    ->where('phone',$phone)
    ->update(['phone3' =>$phone2,'sim3_serial'=>$sim2_serial,'sim3_user_network'=>$sim2_network]);
    return response()->json(['code'=>'0000',"description"=>'Sim Added']);
        
    }
    
    else if($user->phone4==null || $user->phone4=='')
    {
     DB::table('users')
    ->where('phone',$phone)
    ->update(['phone4' =>$phone2,'sim4_serial'=>$sim2_serial,'sim4_user_network'=>$sim2_network]);
    return response()->json(['code'=>'0000',"description"=>'Sim Added']);
        
    }else
    {
        
        return response()->json(['code'=>'0000',"description"=>'You have reached the maximum limit']);
    }
    
    
    //return $phone;
    // $active=new activity_log();
    // $active->user_id=$user->id;
    // $active->ip=$ip;
    // $active->log=$longitude;
    // $active->lat=$latitude;
    // $active->nationality=$nationality;
    // $active->log_dec=$latitude_dec;
    // $active->action='Add Sim';
    // $active->save();
   // return response()->json(['code'=>'0000',"description"=>'Sim Added']);
    
   //search if phone2 is set
   //check if phone2 number is available
   
   $user_match=['phone2'=>$phone];
   $sim2=User::where($user_match)->first();
   
   
 
   return $sim2;
   if(!isset($sim2))
   {
   
    
   }
   
   $user_match=['phone3'=>$phone];
   $sim3=User::where($user_match)->first();
   
    if(!isset($sim3))
   {
    DB::table('users')
    ->where('phone',$phone)
    ->update(['phone3' =>$phone2,'sim2_serial'=>$sim2_serial,'sim2_user_network'=>$sim2_network]);
    return response()->json(['code'=>'0000',"description"=>'Sim Added']);
    
   }
   
   $user_match=['phone4'=>$phone];
   $sim4=User::where($user_match)->first();
   
   if(!isset($sim4))
   {
    DB::table('users')
    ->where('phone',$phone)
    ->update(['phone4' =>$phone2,'sim2_serial'=>$sim2_serial,'sim2_user_network'=>$sim2_network]);
    return response()->json(['code'=>'0000',"description"=>'Sim Added']);
    
   }
   
    
    
    
    
    //save the activity log

 }

public function ussd_receipt(Request $request)
{    
	 Log::info(print_r($_REQUEST,true));
	Log::info(print_r($_POST,true));
    Log::info(print_r($_FILES,true));
$file_content = file_get_contents('php://input');
Log::info(print_r($file_content,true));
 
   $message=$request->response;
   $ref=$request->ref;
 
   $match=['api_ref'=>$ref];
   $transearc=Transaction::where($match)->first();

   $a = $message;
   $is_processed=0;
if (strpos($a, 'will be processed in a short time') !== false) {
    $is_processed=1;
}else if(strpos($a, 'Thanks for using share n sell service. Your request is being processed!, OK') !== false)
{
    $is_processed=1;
}
    if($is_processed==1)
    {
    // DB::table('transaction')
    // ->where('api_ref',$ref)
    // ->update(['status' =>1,'ussd_response_message'=>$message]);
    }
}
public function login(Request $request)
{



   $this->validate($request, [
        'username'=>'required',
        'hash' => 'required',
        'password'=>'required'
    ]);
    
$password = $request->header('Password');
$username = $request->header('Username');


       $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;
        
        
        
        

 if($username=="tingtel" && $password=="967@1#-%3*")
    {
      try{
$username=$request->username;
$password=$request->password;
$hash=$request->hash;
$hash_key="CBOPAY967834612944";
//manipulate the hash algorithm
$data=$username.$password.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);

}

//get user information
$user_match=['username'=>$request->username];
$user=User::where($user_match)->first();

//let log the activity of the user




if(!isset($user))
{
  return response()->json(['code'=>'9999','description'=>'User Not Exist']);
}
if (Hash::check($request->password, $user->password)) {
    
                $users = DB::table('users')
                ->where($user_match)
                ->select('first_name','last_name','phone','email')
                ->get(); 
                
                
$active=new activity_log();
$active->user_id=$user->id;
$active->ip=$ip;
$active->log=$longitude;
$active->lat=$latitude;
$active->nationality=$nationality;
$active->log_dec=$latitude_dec;
$active->action='login';
$active->save();

 $sim1 = DB::table('users')
                ->where($user_match)
                ->select('phone','sim1_serial','user_network')
                ->get();


$sim2 = DB::table('users')
                ->where($user_match)
                ->select('phone2','sim2_serial','sim2_user_network')
                ->get();
                
$sim3 = DB::table('users')
                ->where($user_match)
                ->select('phone3','sim3_serial','sim3_user_network')
                ->get(); 
                
$sim4 = DB::table('users')
                ->where($user_match)
                ->select('phone4','sim4_serial','sim4_user_network')
                ->get(); 
return response()->json(['code'=>'0000','description'=>'Successful!','user_info'=>$users,'sim1'=>$sim1,'sim2'=>$sim2,'sim3'=>$sim3,'sim4'=>$sim4]);
}
else
{
  return response()->json(['code'=>'9999','description'=>'Invalid Password']);
} 
    
    
}
      catch(\Exception $ex)
      {
    
return response()->json(['code'=>'9999','description'=>'Server Error']);
    
    
}  
        
    }else
    {
    return response()->json(['code'=>'9996',"description"=>'Invalid Header Parameter']);
    }
}


public function transfer_credit(Request $request)
{
$pass=false;
$url="https://simhostng.com/api/ussd";
$apiKey="175f620ef9c5d93f69045f6f646dff307bfb3c207a0c366058b84df75addf676";


$number=$request->transaction_string;
$network=$request->network;
$ref="kjhgfdtyukoiuyt5498765456876dh8765";
$callback="http://45.58.119.26/tingtel/api/ussd_receipt";

$password = $request->header('Password');
$username = $request->header('Username');
$hash=$request->hash;

if($username=="tingtel" && $password=="967@1#-%3*")
{
    $pass=true;
}

if($pass!=true)
{
    return response()->json(['code'=>'9996',"description"=>'Invalid Header Parameter']);
}


//hash check algorithm
$hash_key="CBOPAY967834612944";
$data=$number.$network.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
}

if($network=="9mobile")
{
    
$server="CLMTNBFFF";
try{ 
    
$data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER,true); 
curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
$server_output = curl_exec ($ch);
curl_close ($ch);
$result=json_decode($server_output);
$data=$result->data;
$ref=$data[0]->ID;
$response=$data[0]->RESPONSE;

 return response()->json($data[0]->ID);
    
}catch(\Exception $ex)
{
    return response()->json(['code'=>'9999',"description"=>'server error']);
    
    
}
}
else if($network=="Airtel")
{
     return response()->json(['code'=>'9999',"description"=>'Not Available, Coming Soon']);
 try{
     
$data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_POSTFIELDS,
            $data_string);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
$server_output = curl_exec ($ch);
curl_close ($ch);

     
 }catch(\Exception $ex)
 {
      return response()->json(['code'=>'9999',"description"=>'server error']);
     
 }  

    
    
}else if($network=="MTN")
{
    try{
        
    $server="CLMTNBFFF";
    $data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    curl_setopt($ch, CURLOPT_POSTFIELDS,
            $data_string);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
$server_output = curl_exec ($ch);
curl_close ($ch);

     
 }catch(\Exception $ex)
 {
return response()->json(['code'=>'9999',"description"=>'server error']);
     
 }  
    
    
}else if($network=="GLO")
{
     return response()->json(['code'=>'9999',"description"=>'Not Available, Coming Soon']);
 try{
     
     $data_string="apikey=".$apiKey.'&'."server=".$server.'&'."sim=".'1'."&".'number='.$number.'&'.'ref='.$ref."&"."url=".$callback;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_POST, 1);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_POSTFIELDS,
            $data_string);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
$server_output = curl_exec ($ch);
curl_close ($ch);

     
 }catch(\Exception $ex)
 {
      return response()->json(['code'=>'9999',"description"=>'server error']);
     
 }  
    
}

    
}
public function getUserIP()
{
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }
        else
        {
            $ip = $remote;
        }

        return $ip;
    }
    
 public function credit_notification_push(Request $request)
 {
$password = $request->header('Password');
$username = $request->header('Username');
$hash=$request->hash;

$hash=$request->hash;
$hash_key="CBOPAY967834612944";

$data=$username.$password.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);

}
  
      try{
        $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
    $user_match=['phone'=>$request->user_phone];
    $user=User::where($user_match)->first();
    //return $request->user_phone;
    if(!isset($user))
    {
        
        $user_match=['phone2'=>$request->user_phone];
    $user=User::where($user_match)->first();
        
    }
    
     if(!isset($user))
    {
        
        $user_match=['phone3'=>$request->user_phone];
    $user=User::where($user_match)->first();
        
    }
    
     if(!isset($user))
    {
        
        $user_match=['phone4'=>$request->user_phone];
    $user=User::where($user_match)->first();
        
    }
    
    
   if(!isset($user))
   {
    return response()->json(['code'=>'9998','description'=>'User does not exist']);
       
   }
    //save the activity log
    $active=new activity_log();
    $active->user_id=$user->id;
    $active->ip=$ip;
    $active->log=$longitude;
    $active->lat=$latitude;
    $active->nationality=$nationality;
    $active->log_dec=$latitude_dec;
    $active->action='credit_pushed_notification';
    $active->save(); 
      
    $tranc=new Transaction();
    $tranc->amount=$request->amount;
    $tranc->user_phone=$request->user_phone;
    $tranc->source_network=$request->source_network;
    $tranc->beneficiary_network=$request->beneficiary_network;
    $tranc->beneficiary_msisdn=$request->beneficiary_msisdn;
    $tranc->ref=$request->ref;
     $tranc->save();
     return response()->json(['code'=>'0000','description'=>'Successful!','transactions'=>$tranc]);
     }catch(\Exception $ex)
     {
         
      return response()->json(['code'=>'9999','description'=>'Server Error']);
         
     }
     
     
 }
 
 
 public function credit_update_report(Request $request)
 {
     
$password = $request->header('Password');
$username = $request->header('Username');
$hash=$request->hash;

$hash=$request->hash;
$hash_key="CBOPAY967834612944";

$data=$username.$password.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);

}
     try{
    $match=['ref'=>$request->ref];
    $tranc=DB::table('transaction')->where($match)
    ->select('status')
    ->latest()->first();
    return response()->json(['transactions'=>$tranc]);
     }catch(\Exception $ex)
     {  latest('upload_time')->first();
    return response()->json(['code'=>'9999','description'=>'Server Error']);
     }
     
 }

 public function OTP(Request $request)
 {
     
$password = $request->header('Password');
$username = $request->header('Username');
$hash=$request->hash;

$hash=$request->hash;
$hash_key="CBOPAY967834612944";

$data=$username.$password.$hash_key;
$hashed =hash('sha512', $data);
if($hash!=$hashed)
{
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);

}  
     
     
        $ip=self::getUserIP();
        $url='https://api.ipgeolocationapi.com/geolocate/'.$ip;
       
        $data=file_get_contents($url);
        $result=json_decode($data);
        
        $region=$result->region;
        $subregion=$result->subregion;
        $nationality=$result->nationality;
        $latitude=$result->geo->latitude;
        $longitude=$result->geo->longitude;
        $latitude_dec=$result->geo->latitude_dec;      
          
          
          
    // $user_match=['phone'=>$request->phone_number];
    // $user=User::where($user_match)->first();
    
    // if(!isset($user))
    // {
    //      return response()->json(['code'=>'9998','description'=>'User does not exist']);
        
    // }
    
    
    $active=new activity_log();
    $active->user_id=1;
    $active->ip=$ip;
    $active->log=$longitude;
    $active->lat=$latitude;
    $active->nationality=$nationality;
    $active->log_dec=$latitude_dec;
    $active->action='otp'.$request->otp;
    $active->save(); 
          
    $network=strtolower($request->network);

    $message=$request->otp;
    $msisdn=$request->phone_number;
    switch($network)
    {
        case 'mtn':
             $result=self::mtn_message($message,$msisdn);
             return $result;
            break;
         case 'airtel':
               $result=self::airtel_message($message,$msisdn);
               return  $result;
             break;
        case '9mobile':
            $result=self::ninemobile_message($message,$msisdn);
            return $result;
             break;
             
         case 'glo':
            $result=self::glo_message($message,$msisdn);
            return $result;
             break;
        default:
            
            return "Not A Support Network";
            
    }    
     
 }
function gen_uuid() {
    return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        // 32 bits for "time_low"
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

        // 16 bits for "time_mid"
        mt_rand( 0, 0xffff ),

        // 16 bits for "time_hi_and_version",
        // four most significant bits holds version number 4
        mt_rand( 0, 0x0fff ) | 0x4000,

        // 16 bits, 8 bits for "clk_seq_hi_res",
        // 8 bits for "clk_seq_low",
        // two most significant bits holds zero and one for variant DCE1.1
        mt_rand( 0, 0x3fff ) | 0x8000,

        // 48 bits for "node"
        mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
    );
}
 
 function mtn_message($message,$msisdn)
  {
      

try{
    $code="4507";
    $timeStamp=date('Ymdhms');
    $spid='2340110002479';
    $origina_tel='tel:'.$msisdn;
    $password="bmeB600";
    $response=$message;
    $spPassword=md5($spid.$password.$timeStamp);
    $bundleid=256000039;
    $serviceid='234012000024060';
    $endpoint="http://45.58.119.26/api/notifySMSReceipt";
$xml_post_string='<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:loc="http://www.csapi.org/schema/parlayx/sms/send/v2_2/local" xmlns:v2="http://www.huawei.com.cn/schema/common/v2_1">
   <soapenv:Header>
      <v2:RequestSOAPHeader>
         <v2:spId>'.$spid.'</v2:spId>
         <v2:spPassword>'.$spPassword.'</v2:spPassword>
         <v2:timeStamp>'.$timeStamp.'</v2:timeStamp>
         <v2:serviceId>'.$serviceid.'</v2:serviceId>
         <v2:OA>'.$msisdn.'</v2:OA>
         <v2:FA>'.$msisdn.'</v2:FA>
      </v2:RequestSOAPHeader>
   </soapenv:Header>
   <soapenv:Body>
      <loc:sendSms>
         <loc:addresses>'.$origina_tel.'</loc:addresses>
         <loc:senderName>'.$code.'</loc:senderName>
         <loc:message>'.$message.'</loc:message>
         <loc:receiptRequest>
            <endpoint>'.$endpoint.'</endpoint>
            <interfaceName>SmsNotification</interfaceName>
            <correlator>0003</correlator>
         </loc:receiptRequest>
      </loc:sendSms>
   </soapenv:Body>
</soapenv:Envelope>';
                $headers = array(
                        "Content-type: text/xml;charset=\"utf-8\"",
                        "Cache-Control: no-cache",                     
                        "Content-length: ".strlen($xml_post_string),
                    ); 
            $url = "http://41.206.4.162:8310/SendSmsService/services/SendSms";
            $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL,  $url);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
           curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
           curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
           curl_setopt($ch, CURLOPT_POST, 1);
           curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_post_string);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           $response = curl_exec($ch);
          if ($response === false) 
          {
              $response = curl_error($ch);
          }
return response()->json(["msisdn"=>$msisdn,"Code"=>'0000',"description"=>'successful']);

 }catch(\Exception $ex)
 {
   return response()->json(["msisdn"=>$msisdn,"Code"=>'9999',"description"=>'not sent']);
}
      
  }
  
  
   function airtel_message($message,$msisdn)
  {
    try{
       // 99.80.41.227:14013 old 1013
    $url="http://99.80.41.227:14013/cgi-bin/sendsms?username=cloudengine&password=cloudengine&from=4507&to=".rawurlencode($msisdn)."&"."text"."=".rawurlencode($message)."&dlr-mask=31&smsc=".rawurlencode("bbnaija_Airtel");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Important
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
   $result = curl_exec($ch);
if (curl_errno($ch)) {
return response()->json(["msisdn"=>$msisdn,"Code"=>'9999',"description"=>'failed from network']);
}
curl_close ($ch);

 return response()->json(["msisdn"=>$msisdn,"Code"=>'0000',"description"=>'successful']);

       }
    catch(\Exception $ex){
    return response()->json(["msisdn"=>$msisdn,"Code"=>'9999',"description"=>'not sent']);
       }
  }
  
  function ninemobile_message($message,$msisdn)
  {
      try{
        $code="4507";
        $smsc="bbnaija_9mobile";
        $url="http://99.80.41.227:14013/cgi-bin/sendsms?username=cloudengine&password=cloudengine&from=".rawurlencode($code)."&"."to=".rawurlencode($msisdn)."&"."text"."=".rawurlencode($message)."&dlr-mask=31&smsc=".$smsc;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //Important
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        $result = curl_exec($ch);
if (curl_errno($ch)) {
return response()->json(["msisdn"=>$msisdn,"Code"=>'9999',"description"=>'failed from network']);
}
curl_close ($ch);
return response()->json(["msisdn"=>$msisdn,"Code"=>'0000',"description"=>'successful']);
      }
      catch(\Exception $ex)
      {
        return response()->json(["msisdn"=>$msisdn,"Code"=>'9999',"description"=>'not sent']);
      }
   

  }
 
  public function validate_user(Request $request)
  {
      
      
try
{
    $password = $request->header('Password');
  $username = $request->header('Username');
  $transaction=$request->transaction_value;
  $hash=$request->hash;
  $hash_key="CBOPAY967834612944";
  $data=$username.$password.$hash_key;
  $hashed =hash('sha512', $data);
  if($hash!=$hashed)
  {
  return response()->json(['code'=>'9998','description'=>'Invalid Hash Key']);
  }  
   $user_match=['email'=>$transaction];
    $result1=User::where($user_match)->first();
    
    if(isset($result1))
    {
      
      
      return response()->json(['code'=>'0000','data'=>$result1]);
        
        
        
    }
    
    $user_match=['phone'=>$transaction];
    $result2=User::where($user_match)->first();
    
    if(isset($result2))
    {
      
      
      return response()->json(['code'=>'0000','data'=>$result2]);
        
        
        
    }
    $user_match=['username'=>$transaction];
    $result3=User::where($user_match)->first();
    if(isset($result3))
    {
      
      
      return response()->json(['code'=>'0000','data'=>$result3]);
        
        
        
    }
 return response()->json(['code'=>'9999','data'=>new stdClass]);
 
}
catch(Exception $ex)
{
    return response()->json(['code'=>'9999','data'=>new stdClass]);
    
}
  
      
      
      
      
  }
  
  public function glo_message($message,$msisdn)
  {
      
      try{
     if(isset($request->from))
     {
         $from=$request->from;
     }else
     {
           $from="Soccerrave";
     }
     $to=$msisdn;
     $text=$message;
        $ch = curl_init();
      $data = array("to" =>$to, "from"=>$from,"text"=>$text);       
      $data_string = json_encode($data);             
      $ch = curl_init('http://45.58.119.26/api/external_sms');
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);  
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(  
     'Content-Type: application/json',
     'Content-Length: ' . strlen($data_string)));              
     $result = curl_exec($ch);
     Log::info((string)$result);
     curl_close($ch);
    return response()->json(["msisdn"=>$msisdn,"Code"=>'0000',"description"=>'successful']);
      }catch(\Exception $ex)
      {
           return response()->json(["msisdn"=>$msisdn,"Code"=>'9999',"description"=>'not sent']);
      }
     
   
  }
  
     
    
}

